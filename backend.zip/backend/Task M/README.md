# Task Management REST API

A scalable RESTful Task Management Service built in Go with PostgreSQL, sqlc, and Gin framework.

## Features

- **REST APIs**: Create, List, Get, and Delete tasks
- **PostgreSQL** with **sqlc** for type-safe database queries
- **JWT Authentication** with role-based authorization
- **Clean Architecture**: Separation of concerns (handlers, services, repositories)
- **Gin Framework** for HTTP routing

## Project Structure

```
task-management/
├── main.go                 # Application entry point
├── db/
│   ├── schema.sql          # PostgreSQL schema
│   └── query.sql           # SQL queries for sqlc
├── internal/
│   ├── auth/               # JWT authentication & middleware
│   ├── config/             # Configuration from env
│   ├── database/           # Database connection pool
│   └── db/                 # sqlc generated code
├── services/
│   ├── auth/               # Auth handlers (login, register)
│   └── tasks/              # Task API handlers
│       ├── constants.go    # Task-related constants
│       ├── models.go       # Request/Response models
│       ├── task_helpers.go # Helper functions
│       ├── task_create.go  # POST /tasks
│       ├── task_list.go    # GET /tasks
│       ├── task_get.go     # GET /tasks/{id}
│       └── task_delete.go  # DELETE /tasks/{id}
├── docker-compose.yml
├── Dockerfile
└── README.md
```

## API Endpoints

### Public Endpoints

| Method | Endpoint    | Description        |
|--------|-------------|--------------------|
| POST   | /register   | Register new user  |
| POST   | /login      | Login and get JWT  |
| GET    | /health     | Health check       |

### Protected Endpoints (Require JWT)

| Method | Endpoint    | Description           |
|--------|-------------|-----------------------|
| POST   | /tasks      | Create a task         |
| GET    | /tasks      | List tasks            |
| GET    | /tasks/:id  | Get task by ID        |
| DELETE | /tasks/:id  | Delete a task         |

### Authorization

- **Users**: Can access only their own tasks
- **Admins**: Can access all tasks

## Task Model

```json
{
  "id": "uuid",
  "title": "string",
  "description": "string",
  "status": "pending | in_progress | completed",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

## Setup

### Prerequisites

- Go 1.21+
- PostgreSQL 16+
- sqlc (optional, for regenerating db code)

### Environment Variables

| Variable           | Default                                      | Description        |
|--------------------|----------------------------------------------|--------------------|
| PORT               | 8080                                         | Server port        |
| DATABASE_URL       | postgresql://postgres:postgres@localhost:5432/task_management?sslmode=disable | DB connection      |
| JWT_SECRET         | your-secret-key-change-in-production         | JWT signing secret |
| JWT_EXPIRY_MINUTES | 60                                           | Token expiry       |

### Running with Docker

```bash
# Start PostgreSQL and the app
docker-compose up -d

# View logs
docker-compose logs -f app
```

### Running Locally

```bash
# 1. Start PostgreSQL (or use Docker)
docker run -d --name pg -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=task_management -p 5432:5432 postgres:16-alpine

# 2. Create schema
psql -U postgres -h localhost -d task_management -f db/schema.sql

# 3. Run the application
go run main.go
```

### Generate sqlc Code (Optional)

```bash
# Install sqlc
go install github.com/sqlc-dev/sqlc/cmd/sqlc@latest

# Generate
sqlc generate
```

## API Usage Examples

### 1. Register a User

```bash
curl -X POST http://localhost:8080/register \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","username":"user1","password":"secret123"}'
```

### 2. Login

```bash
curl -X POST http://localhost:8080/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"secret123"}'
```

### 3. Create Task (use token from login)

```bash
curl -X POST http://localhost:8080/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <YOUR_JWT_TOKEN>" \
  -d '{"title":"My Task","description":"Task description","status":"pending"}'
```

### 4. List Tasks

```bash
curl -X GET http://localhost:8080/tasks \
  -H "Authorization: Bearer <YOUR_JWT_TOKEN>"
```

### 5. Get Task by ID

```bash
curl -X GET http://localhost:8080/tasks/<TASK_ID> \
  -H "Authorization: Bearer <YOUR_JWT_TOKEN>"
```

### 6. Delete Task

```bash
curl -X DELETE http://localhost:8080/tasks/<TASK_ID> \
  -H "Authorization: Bearer <YOUR_JWT_TOKEN>"
```

## Error Response Format

```json
{
  "status": "error",
  "message": "Error description",
  "msg_id": "ERROR_CODE",
  "errors": ["detail1", "detail2"]
}
```

## Postman Collection

Import the Postman collection from `postman/Task_Management_API.postman_collection.json` to test all endpoints.

**Workflow:**
1. Run **Login** or **Register** – the JWT token is saved automatically
2. Run **Create Task** – the task ID is saved for Get/Delete
3. Use **List Tasks**, **Get Task by ID**, or **Delete Task** as needed

**Collection variables:**
- `base_url` – API base URL (default: http://localhost:8080)
- `token` – JWT (auto-set after Login/Register)
- `task_id` – Last created task ID (auto-set after Create Task)

## License

MIT
