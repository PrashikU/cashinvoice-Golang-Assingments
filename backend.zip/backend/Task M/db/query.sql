-- name: CreateTask :one
INSERT INTO tasks (user_id, title, description, status)
VALUES ($1, $2, $3, $4)
RETURNING *;

-- name: GetTaskByID :one
SELECT * FROM tasks
WHERE id = $1;

-- name: ListTasksByUserID :many
SELECT * FROM tasks
WHERE user_id = $1
ORDER BY created_at DESC;

-- name: ListAllTasks :many
SELECT * FROM tasks
ORDER BY created_at DESC;

-- name: DeleteTask :exec
DELETE FROM tasks
WHERE id = $1;

-- name: UpdateTaskStatus :one
UPDATE tasks
SET status = $2, updated_at = NOW()
WHERE id = $1
RETURNING *;

-- name: GetUserByEmail :one
SELECT * FROM users
WHERE email = $1;

-- name: GetUserByID :one
SELECT * FROM users
WHERE id = $1;

-- name: CreateUser :one
INSERT INTO users (email, username, password_hash, role)
VALUES ($1, $2, $3, COALESCE($4, 'user'))
RETURNING id, email, username, role, created_at, updated_at;
