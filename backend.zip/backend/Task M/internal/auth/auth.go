package auth

import (
	"errors"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
)

var (
	ErrInvalidToken = errors.New("invalid token")
	ErrExpiredToken = errors.New("token expired")
)

const ValTagUnauthorized = "unauthorized"

type Claims struct {
	UserID uuid.UUID `json:"user_id"`
	Email  string    `json:"email"`
	Role   string    `json:"role"`
	jwt.RegisteredClaims
}

type AuthContext struct {
	UserID uuid.UUID
	Email  string
	Role   string
}

func GenerateToken(userID uuid.UUID, email, role, secret string, expiryMinutes int) (string, error) {
	claims := &Claims{
		UserID: userID,
		Email:  email,
		Role:   role,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Duration(expiryMinutes) * time.Minute)),
			IssuedAt: jwt.NewNumericDate(time.Now()),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(secret))
}

func ValidateToken(tokenString, secret string) (*Claims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &Claims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(secret), nil
	})
	if err != nil {
		return nil, err
	}
	claims, ok := token.Claims.(*Claims)
	if !ok || !token.Valid {
		return nil, ErrInvalidToken
	}
	return claims, nil
}

func GetAuthContext(c *gin.Context) (*AuthContext, bool) {
	val, exists := c.Get("auth_context")
	if !exists {
		return nil, false
	}
	authCtx, ok := val.(*AuthContext)
	return authCtx, ok
}

func IsAdmin(role string) bool {
	return role == "admin"
}

func CanAccessTask(userID uuid.UUID, taskUserID uuid.UUID, role string) bool {
	if IsAdmin(role) {
		return true
	}
	return userID == taskUserID
}
