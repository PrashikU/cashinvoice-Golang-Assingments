package auth

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func JWTAuthMiddleware(secret string) gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.JSON(http.StatusUnauthorized, gin.H{
				"status":  "error",
				"message": "Authorization header required",
				"msg_id":  "UNAUTHORIZED",
			})
			c.Abort()
			return
		}

		parts := strings.SplitN(strings.TrimSpace(authHeader), " ", 2)
		if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
			c.JSON(http.StatusUnauthorized, gin.H{
				"status":  "error",
				"message": "Invalid authorization format. Use: Bearer <token>",
				"msg_id":  "UNAUTHORIZED",
			})
			c.Abort()
			return
		}

		tokenString := strings.TrimSpace(parts[1])
		if tokenString == "" {
			c.JSON(http.StatusUnauthorized, gin.H{
				"status":  "error",
				"message": "Token is required. Please login or register first to get a JWT token.",
				"msg_id":  "UNAUTHORIZED",
			})
			c.Abort()
			return
		}

		claims, err := ValidateToken(tokenString, secret)
		if err != nil {
			status := http.StatusUnauthorized
			if err == ErrExpiredToken {
				c.JSON(status, gin.H{
					"status":  "error",
					"message": "Token expired",
					"msg_id":  "TOKEN_EXPIRED",
				})
			} else {
				c.JSON(status, gin.H{
					"status":  "error",
					"message": "Invalid token",
					"msg_id":  "UNAUTHORIZED",
				})
			}
			c.Abort()
			return
		}

		c.Set("auth_context", &AuthContext{
			UserID: claims.UserID,
			Email:  claims.Email,
			Role:   claims.Role,
		})
		c.Next()
	}
}
