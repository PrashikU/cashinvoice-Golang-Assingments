package config

import (
	"os"
	"strconv"
)

type Config struct {
	ServerPort   string
	DBURL        string
	JWTSecret    string
	JWTExpiryMin int
}

func Load() *Config {
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	dbURL := os.Getenv("DATABASE_URL")
	if dbURL == "" {
		dbURL = "postgresql://postgres:postgres@localhost:5432/task_management?sslmode=disable"
	}

	jwtSecret := os.Getenv("JWT_SECRET")
	if jwtSecret == "" {
		jwtSecret = "your-secret-key-change-in-production"
	}

	expiryMin := 60
	if e := os.Getenv("JWT_EXPIRY_MINUTES"); e != "" {
		if v, err := strconv.Atoi(e); err == nil {
			expiryMin = v
		}
	}

	return &Config{
		ServerPort:   port,
		DBURL:        dbURL,
		JWTSecret:    jwtSecret,
		JWTExpiryMin: expiryMin,
	}
}
