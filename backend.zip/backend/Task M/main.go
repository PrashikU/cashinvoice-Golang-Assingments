package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"task-management/internal/auth"
	"task-management/internal/config"
	"task-management/internal/database"
	"task-management/internal/db"
	authsvc "task-management/services/auth"
	"task-management/services/tasks"

	"github.com/gin-gonic/gin"
)

func main() {
	// Load .env if present
	_ = os.Setenv("GIN_MODE", "release")

	cfg := config.Load()

	ctx := context.Background()
	pool, err := database.NewPool(ctx, cfg.DBURL)
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	defer pool.Close()

	queries := db.New(pool)

	// Auth handler
	authHandler := &authsvc.AuthHandler{Querier: queries}

	// Task handler
	taskHandler := &tasks.Handler{Querier: queries}

	// JWT middleware
	jwtMiddleware := auth.JWTAuthMiddleware(cfg.JWTSecret)

	router := gin.Default()

	// Return JSON for 404 instead of "404 page not found" HTML
	router.NoRoute(func(c *gin.Context) {
		c.JSON(http.StatusNotFound, gin.H{
			"status":  "error",
			"message": "Route not found",
			"path":    c.Request.URL.Path,
			"method":  c.Request.Method,
		})
	})

	// Health check
	router.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})

	// Auth routes (public)
	router.POST("/register", func(c *gin.Context) {
		authHandler.HandleRegister(c, cfg.JWTSecret, cfg.JWTExpiryMin)
	})
	router.POST("/login", func(c *gin.Context) {
		authHandler.HandleLogin(c, cfg.JWTSecret, cfg.JWTExpiryMin)
	})

	// Task routes (protected)
	tasksGroup := router.Group("/tasks")
	tasksGroup.Use(jwtMiddleware)
	{
		tasksGroup.POST("", taskHandler.HandleTaskCreate)
		tasksGroup.GET("", taskHandler.HandleTaskList)
		tasksGroup.GET("/:id", taskHandler.HandleTaskGet)
		tasksGroup.DELETE("/:id", taskHandler.HandleTaskDelete)
	}

	srv := &http.Server{
		Addr:    ":" + cfg.ServerPort,
		Handler: router,
	}

	go func() {
		log.Printf("Server starting on port %s", cfg.ServerPort)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server failed: %v", err)
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Fatalf("Server forced to shutdown: %v", err)
	}
	log.Println("Server exited")
}
