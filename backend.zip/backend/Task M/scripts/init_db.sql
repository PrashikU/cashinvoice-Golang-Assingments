-- Run this script to initialize the database schema
-- Usage: psql -U postgres -d task_management -f scripts/init_db.sql

\i ../db/schema.sql
