package authsvc

import (
	"net/http"

	authpkg "task-management/internal/auth"
	"task-management/internal/db"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

func (h *AuthHandler) HandleLogin(ctx *gin.Context, jwtSecret string, jwtExpiryMin int) {
	var req LoginRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"status":  "error",
			"message": "Invalid request",
			"errors":  []string{err.Error()},
		})
		return
	}

	user, err := h.Querier.GetUserByEmail(ctx.Request.Context(), req.Email)
	if err != nil {
		ctx.JSON(http.StatusUnauthorized, gin.H{
			"status":  "error",
			"message": "Invalid email or password",
		})
		return
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)); err != nil {
		ctx.JSON(http.StatusUnauthorized, gin.H{
			"status":  "error",
			"message": "Invalid email or password",
		})
		return
	}

	token, err := authpkg.GenerateToken(db.PgtypeToUUID(user.ID), user.Email, user.Role, jwtSecret, jwtExpiryMin)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "Failed to generate token",
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "success",
		"data": TokenResponse{
			Token: token,
			User: struct {
				ID       string `json:"id"`
				Email    string `json:"email"`
				Username string `json:"username"`
				Role     string `json:"role"`
			}{
				ID:       db.PgtypeUUIDToString(user.ID),
				Email:    user.Email,
				Username: user.Username,
				Role:     user.Role,
			},
		},
	})
}
