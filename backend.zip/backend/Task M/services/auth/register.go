package authsvc

import (
	"net/http"

	authpkg "task-management/internal/auth"
	"task-management/internal/db"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

func (h *AuthHandler) HandleRegister(ctx *gin.Context, jwtSecret string, jwtExpiryMin int) {
	var req RegisterRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"status":  "error",
			"message": "Invalid request",
			"errors":  []string{err.Error()},
		})
		return
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "Failed to process password",
		})
		return
	}

	role := "user"
	if req.Role == "admin" {
		role = "admin"
	}

	createUserParams := db.CreateUserParams{
		Email:        req.Email,
		Username:     req.Username,
		PasswordHash: string(hashedPassword),
		Column4:      &role,
	}
	userRow, err := h.Querier.CreateUser(ctx.Request.Context(), createUserParams)
	if err != nil {
		ctx.JSON(http.StatusConflict, gin.H{
			"status":  "error",
			"message": "User with this email or username already exists",
		})
		return
	}

	token, err := authpkg.GenerateToken(db.PgtypeToUUID(userRow.ID), userRow.Email, userRow.Role, jwtSecret, jwtExpiryMin)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "Failed to generate token",
		})
		return
	}

	ctx.JSON(http.StatusCreated, gin.H{
		"status": "success",
		"data": TokenResponse{
			Token: token,
			User: struct {
				ID       string `json:"id"`
				Email    string `json:"email"`
				Username string `json:"username"`
				Role     string `json:"role"`
			}{
				ID:       db.PgtypeUUIDToString(userRow.ID),
				Email:    userRow.Email,
				Username: userRow.Username,
				Role:     userRow.Role,
			},
		},
	})
}
