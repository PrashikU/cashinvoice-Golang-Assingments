package tasks

const (
	ModuleTasks = "tasks"

	// API endpoint names
	APITaskCreate = "TaskCreate"  // POST /tasks
	APITaskList   = "TaskList"    // GET /tasks
	APITaskGet    = "TaskGet"     // GET /tasks/:id
	APITaskDelete = "TaskDelete"  // DELETE /tasks/:id

	// Task status values
	StatusPending    = "pending"
	StatusInProgress = "in_progress"
	StatusCompleted  = "completed"

	// Message IDs for error responses
	MsgIDValidationError   = "VALIDATION_ERROR"
	MsgIDUnauthorized      = "UNAUTHORIZED"
	MsgIDNotFound          = "NOT_FOUND"
	MsgIDForbidden         = "FORBIDDEN"
	MsgIDInternalError     = "INTERNAL_ERROR"
	MsgIDInvalidStatus     = "INVALID_STATUS"

	// Validation tags
	ValTagRequired    = "required"
	ValTagInvalid     = "invalid"
	ValTagUnauthorized = "unauthorized"
	ValTagNotFound     = "not_found"
	ValTagForbidden    = "forbidden"
)
