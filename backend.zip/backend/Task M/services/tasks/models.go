package tasks

import (
	"time"
)

// TaskCreateRequest represents the request body for creating a task
type TaskCreateRequest struct {
	Title       string `json:"title" binding:"required"`
	Description string `json:"description"`
	Status      string `json:"status"`
}


// TaskResponse represents the API response for a task
type TaskResponse struct {
	ID          string    `json:"id"`
	UserID      string    `json:"user_id"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	Status      string    `json:"status"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// TaskListResponse represents the API response for listing tasks
type TaskListResponse struct {
	Count int            `json:"count"`
	Tasks []TaskResponse `json:"tasks"`
}

// ErrorResponse represents a consistent JSON error response
type ErrorResponse struct {
	Status  string   `json:"status"`
	Message string   `json:"message"`
	MsgID   string   `json:"msg_id,omitempty"`
	Errors  []string `json:"errors,omitempty"`
}

// SuccessResponse represents a consistent JSON success response
type SuccessResponse struct {
	Status  string      `json:"status"`
	Message string      `json:"message,omitempty"`
	Data    interface{} `json:"data"`
}
