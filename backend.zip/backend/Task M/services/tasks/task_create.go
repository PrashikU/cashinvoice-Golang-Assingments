package tasks

import (
	"net/http"

	"task-management/internal/auth"
	"task-management/internal/db"

	"github.com/gin-gonic/gin"
)

// Handler holds dependencies for task handlers
type Handler struct {
	Querier db.Querier
}

// HandleTaskCreate handles POST /tasks - Create a task
func (h *Handler) HandleTaskCreate(ctx *gin.Context) {
	authCtx, ok := auth.GetAuthContext(ctx)
	if !ok {
		ctx.JSON(http.StatusUnauthorized, ErrorResponse{
			Status:  "error",
			Message: "Unauthorized",
			MsgID:   MsgIDUnauthorized,
			Errors:  []string{auth.ValTagUnauthorized},
		})
		return
	}

	var req TaskCreateRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, ErrorResponse{
			Status:  "error",
			Message: "Invalid request body",
			MsgID:   MsgIDValidationError,
			Errors:  []string{err.Error()},
		})
		return
	}

	// Validate title
	if req.Title == "" {
		ctx.JSON(http.StatusBadRequest, ErrorResponse{
			Status:  "error",
			Message: "Title is required",
			MsgID:   MsgIDValidationError,
			Errors:  []string{"title: " + ValTagRequired},
		})
		return
	}

	// Validate status if provided
	if req.Status != "" && !IsValidStatus(req.Status) {
		ctx.JSON(http.StatusBadRequest, ErrorResponse{
			Status:  "error",
			Message: "Invalid status. Must be one of: pending, in_progress, completed",
			MsgID:   MsgIDInvalidStatus,
			Errors:  []string{"status: " + ValTagInvalid},
		})
		return
	}

	status := DefaultStatus(req.Status)
	task, err := h.Querier.CreateTask(ctx.Request.Context(), db.CreateTaskParams{
		UserID:      db.UUIDToPgtype(authCtx.UserID),
		Title:       req.Title,
		Description: db.StringToPgtypeText(req.Description),
		Status:      status,
	})
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, ErrorResponse{
			Status:  "error",
			Message: "Failed to create task",
			MsgID:   MsgIDInternalError,
			Errors:  []string{err.Error()},
		})
		return
	}

	ctx.JSON(http.StatusCreated, SuccessResponse{
		Status:  "success",
		Message: "Task created successfully",
		Data:    TaskToResponse(task),
	})
}
