package tasks

import (
	"net/http"

	"task-management/internal/auth"
	"task-management/internal/db"

	"github.com/gin-gonic/gin"
)

// HandleTaskDelete handles DELETE /tasks/:id - Delete task
func (h *Handler) HandleTaskDelete(ctx *gin.Context) {
	authCtx, ok := auth.GetAuthContext(ctx)
	if !ok {
		ctx.JSON(http.StatusUnauthorized, ErrorResponse{
			Status:  "error",
			Message: "Unauthorized",
			MsgID:   MsgIDUnauthorized,
			Errors:  []string{auth.ValTagUnauthorized},
		})
		return
	}

	taskID, err := ParseTaskID(ctx.Param("id"))
	if err != nil {
		ctx.JSON(http.StatusBadRequest, ErrorResponse{
			Status:  "error",
			Message: "Invalid task ID format",
			MsgID:   MsgIDValidationError,
			Errors:  []string{"id: " + ValTagInvalid},
		})
		return
	}

	task, err := h.Querier.GetTaskByID(ctx.Request.Context(), db.UUIDToPgtype(taskID))
	if err != nil {
		ctx.JSON(http.StatusNotFound, ErrorResponse{
			Status:  "error",
			Message: "Task not found",
			MsgID:   MsgIDNotFound,
			Errors:  []string{ValTagNotFound},
		})
		return
	}

	if !auth.CanAccessTask(authCtx.UserID, db.PgtypeToUUID(task.UserID), authCtx.Role) {
		ctx.JSON(http.StatusForbidden, ErrorResponse{
			Status:  "error",
			Message: "Access denied. You can only delete your own tasks.",
			MsgID:   MsgIDForbidden,
			Errors:  []string{ValTagForbidden},
		})
		return
	}

	err = h.Querier.DeleteTask(ctx.Request.Context(), db.UUIDToPgtype(taskID))
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, ErrorResponse{
			Status:  "error",
			Message: "Failed to delete task",
			MsgID:   MsgIDInternalError,
			Errors:  []string{err.Error()},
		})
		return
	}

	ctx.JSON(http.StatusOK, SuccessResponse{
		Status:  "success",
		Message: "Task deleted successfully",
		Data:    gin.H{"id": taskID.String()},
	})
}
