package tasks

import (
	"task-management/internal/db"

	"github.com/google/uuid"
)

// ValidTaskStatuses returns the list of valid task status values
func ValidTaskStatuses() []string {
	return []string{StatusPending, StatusInProgress, StatusCompleted}
}

// IsValidStatus checks if the given status is valid
func IsValidStatus(status string) bool {
	for _, s := range ValidTaskStatuses() {
		if s == status {
			return true
		}
	}
	return false
}

// DefaultStatus returns the default status when not provided
func DefaultStatus(status string) db.TaskStatus {
	if status == "" {
		return db.TaskStatusPending
	}
	if !IsValidStatus(status) {
		return db.TaskStatusPending
	}
	return db.TaskStatus(status)
}

// TaskToResponse converts db.Task to TaskResponse
func TaskToResponse(task db.Task) TaskResponse {
	resp := TaskResponse{
		ID:          db.PgtypeUUIDToString(task.ID),
		UserID:      db.PgtypeUUIDToString(task.UserID),
		Title:       task.Title,
		Description: db.PgtypeTextToString(task.Description),
		Status:      string(task.Status),
	}
	if task.CreatedAt.Valid {
		resp.CreatedAt = task.CreatedAt.Time
	}
	if task.UpdatedAt.Valid {
		resp.UpdatedAt = task.UpdatedAt.Time
	}
	return resp
}

// TasksToResponses converts a slice of db.Task to TaskResponse slice
func TasksToResponses(tasks []db.Task) []TaskResponse {
	responses := make([]TaskResponse, len(tasks))
	for i, task := range tasks {
		responses[i] = TaskToResponse(task)
	}
	return responses
}

// ParseTaskID parses a string to UUID, returns error if invalid
func ParseTaskID(idStr string) (uuid.UUID, error) {
	return uuid.Parse(idStr)
}
