package tasks

import (
	"net/http"

	"task-management/internal/auth"
	"task-management/internal/db"

	"github.com/gin-gonic/gin"
)

// HandleTaskList handles GET /tasks - List tasks
func (h *Handler) HandleTaskList(ctx *gin.Context) {
	authCtx, ok := auth.GetAuthContext(ctx)
	if !ok {
		ctx.JSON(http.StatusUnauthorized, ErrorResponse{
			Status:  "error",
			Message: "Unauthorized",
			MsgID:   MsgIDUnauthorized,
			Errors:  []string{auth.ValTagUnauthorized},
		})
		return
	}

	var tasks []db.Task
	var err error

	if auth.IsAdmin(authCtx.Role) {
		tasks, err = h.Querier.ListAllTasks(ctx.Request.Context())
	} else {
		tasks, err = h.Querier.ListTasksByUserID(ctx.Request.Context(), db.UUIDToPgtype(authCtx.UserID))
	}

	if err != nil {
		ctx.JSON(http.StatusInternalServerError, ErrorResponse{
			Status:  "error",
			Message: "Failed to list tasks",
			MsgID:   MsgIDInternalError,
			Errors:  []string{err.Error()},
		})
		return
	}

	responses := TasksToResponses(tasks)
	ctx.JSON(http.StatusOK, SuccessResponse{
		Status: "success",
		Data: TaskListResponse{
			Count: len(responses),
			Tasks: responses,
		},
	})
}
