package tasks

import (
	"testing"
)

func TestIsValidStatus(t *testing.T) {
	tests := []struct {
		status   string
		expected bool
	}{
		{"pending", true},
		{"in_progress", true},
		{"completed", true},
		{"invalid", false},
		{"", false},
		{"PENDING", false},
	}

	for _, tt := range tests {
		t.Run(tt.status, func(t *testing.T) {
			if got := IsValidStatus(tt.status); got != tt.expected {
				t.Errorf("IsValidStatus(%q) = %v, want %v", tt.status, got, tt.expected)
			}
		})
	}
}

func TestDefaultStatus(t *testing.T) {
	// Test empty status defaults to pending
	if got := DefaultStatus(""); string(got) != StatusPending {
		t.Errorf("DefaultStatus(\"\") = %v, want pending", got)
	}

	// Test invalid status defaults to pending
	if got := DefaultStatus("invalid"); string(got) != StatusPending {
		t.Errorf("DefaultStatus(\"invalid\") = %v, want pending", got)
	}

	// Test valid status is preserved
	if got := DefaultStatus(StatusInProgress); string(got) != StatusInProgress {
		t.Errorf("DefaultStatus(\"in_progress\") = %v, want in_progress", got)
	}
}
