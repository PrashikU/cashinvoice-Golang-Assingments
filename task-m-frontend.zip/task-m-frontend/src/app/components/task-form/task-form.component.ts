import { Component, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TaskService, TaskCreateRequest } from '../../services/task.service';

@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './task-form.component.html',
  styleUrl: './task-form.component.scss'
})
export class TaskFormComponent {
  taskCreated = output<void>();

  title = '';
  description = '';
  status = 'pending';
  loading = false;
  error = '';

  constructor(private taskService: TaskService) {}

  onSubmit(): void {
    this.error = '';
    if (!this.title.trim()) {
      this.error = 'Title is required';
      return;
    }
    this.loading = true;
    const task: TaskCreateRequest = {
      title: this.title.trim(),
      description: this.description.trim() || undefined,
      status: this.status
    };
    this.taskService.createTask(task).subscribe({
      next: (res) => {
        this.loading = false;
        if (res.status === 'success') {
          this.title = '';
          this.description = '';
          this.status = 'pending';
          this.taskCreated.emit();
        } else {
          this.error = res.message || 'Failed to create task';
        }
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error?.message || 'Failed to create task';
      }
    });
  }
}
