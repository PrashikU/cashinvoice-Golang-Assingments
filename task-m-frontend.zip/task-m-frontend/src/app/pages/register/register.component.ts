import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent {
  email = '';
  username = '';
  password = '';
  loading = false;
  error = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) {
    if (auth.isAuthenticated()) {
      router.navigate(['/dashboard']);
    }
  }

  onSubmit(): void {
    this.error = '';
    if (!this.email || !this.username || !this.password) {
      this.error = 'Please fill all fields';
      return;
    }
    this.loading = true;
    this.auth.register(this.email, this.username, this.password).subscribe({
      next: (res) => {
        this.loading = false;
        if (res.status === 'success') {
          this.router.navigate(['/dashboard']);
        } else {
          this.error = res.message || 'Registration failed';
        }
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error?.message || 'Registration failed';
      }
    });
  }
}
