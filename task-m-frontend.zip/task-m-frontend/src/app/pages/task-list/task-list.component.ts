import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TaskService, Task } from '../../services/task.service';
import { TaskFormComponent } from '../../components/task-form/task-form.component';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [RouterLink, TaskFormComponent],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.scss'
})
export class TaskListComponent {
  tasks: Task[] = [];
  loading = true;
  deletingId: string | null = null;

  constructor(private taskService: TaskService) {
    this.loadTasks();
  }

  loadTasks(): void {
    this.loading = true;
    this.taskService.getTasks().subscribe({
      next: (res) => {
        this.loading = false;
        if (res.status === 'success' && res.data) {
          this.tasks = res.data.tasks;
        }
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  onTaskCreated(): void {
    this.loadTasks();
  }

  deleteTask(task: Task): void {
    if (!confirm(`Delete "${task.title}"?`)) return;
    this.deletingId = task.id;
    this.taskService.deleteTask(task.id).subscribe({
      next: () => {
        this.deletingId = null;
        this.loadTasks();
      },
      error: () => {
        this.deletingId = null;
      }
    });
  }

  formatDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  }
}
