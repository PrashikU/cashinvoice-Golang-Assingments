import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, catchError, of } from 'rxjs';
import { environment } from '../../environments/environment';

export interface User {
  id: string;
  email: string;
  username: string;
  role: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface ApiResponse<T> {
  status: string;
  data?: T;
  message?: string;
  errors?: string[];
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly TOKEN_KEY = 'taskm_token';
  private readonly USER_KEY = 'taskm_user';

  private currentUser = signal<User | null>(null);
  private token = signal<string | null>(null);

  isAuthenticated = computed(() => !!this.token());
  user = computed(() => this.currentUser());

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
    this.loadFromStorage();
  }

  private loadFromStorage(): void {
    const storedToken = localStorage.getItem(this.TOKEN_KEY);
    const storedUser = localStorage.getItem(this.USER_KEY);
    if (storedToken && storedUser) {
      this.token.set(storedToken);
      this.currentUser.set(JSON.parse(storedUser));
    }
  }

  register(email: string, username: string, password: string, role?: string): Observable<ApiResponse<AuthResponse>> {
    const body = role ? { email, username, password, role } : { email, username, password };
    return this.http.post<ApiResponse<AuthResponse>>(`${environment.apiUrl}/register`, body).pipe(
      tap(res => {
        if (res.status === 'success' && res.data) {
          this.setSession(res.data);
        }
      }),
      catchError(err => of(err.error || { status: 'error', message: 'Registration failed' }))
    );
  }

  login(email: string, password: string): Observable<ApiResponse<AuthResponse>> {
    return this.http.post<ApiResponse<AuthResponse>>(`${environment.apiUrl}/login`, { email, password }).pipe(
      tap(res => {
        if (res.status === 'success' && res.data) {
          this.setSession(res.data);
        }
      }),
      catchError(err => of(err.error || { status: 'error', message: 'Login failed' }))
    );
  }

  private setSession(data: AuthResponse): void {
    this.token.set(data.token);
    this.currentUser.set(data.user);
    localStorage.setItem(this.TOKEN_KEY, data.token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(data.user));
  }

  logout(): void {
    this.token.set(null);
    this.currentUser.set(null);
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return this.token();
  }
}
