import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed';
  created_at: string;
  updated_at: string;
}

export interface TaskCreateRequest {
  title: string;
  description?: string;
  status?: string;
}

export interface TaskListResponse {
  count: number;
  tasks: Task[];
}

export interface ApiResponse<T> {
  status: string;
  data?: T;
  message?: string;
}

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  constructor(
    private http: HttpClient,
    private auth: AuthService
  ) {}

  private getHeaders(): HttpHeaders {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    });
  }

  getTasks(): Observable<ApiResponse<TaskListResponse>> {
    return this.http.get<ApiResponse<TaskListResponse>>(`${environment.apiUrl}/tasks`, {
      headers: this.getHeaders()
    });
  }

  getTask(id: string): Observable<ApiResponse<Task>> {
    return this.http.get<ApiResponse<Task>>(`${environment.apiUrl}/tasks/${id}`, {
      headers: this.getHeaders()
    });
  }

  createTask(task: TaskCreateRequest): Observable<ApiResponse<Task>> {
    return this.http.post<ApiResponse<Task>>(`${environment.apiUrl}/tasks`, task, {
      headers: this.getHeaders()
    });
  }

  deleteTask(id: string): Observable<ApiResponse<unknown>> {
    return this.http.delete<ApiResponse<unknown>>(`${environment.apiUrl}/tasks/${id}`, {
      headers: this.getHeaders()
    });
  }
}
