export const environment = {
  production: false,
  apiUrl: '/api'
};
